package com.ws;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import javax.xml.XMLConstants;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import java.io.File;
import java.io.IOException;

@Controller
public class HomeController {

    @RequestMapping(value = "/{word}/{origin}/{dest}", method = RequestMethod.GET)
    public String translateWords(ModelMap modelMap, @PathVariable String word, @PathVariable String origin, @PathVariable String dest){
        String result = translate(word, origin, dest);
        modelMap.addAttribute("message", result);
        return "hello";
    }

    private static String translate(String word, String origin, String dest){
        String text = "Limba sursa : " + origin  + "<br>Cuvantul : " + word + "<br>Destinatie : " + dest + " <br> Rezultat : " ;
        boolean exista = false;
        DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();

        try {
            dbf.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, true);
            DocumentBuilder db = dbf.newDocumentBuilder();
            Document doc = db.parse(new File("/Users/georg/IdeaProjects/vshome/src/main/resources/lang.xml"));
            doc.getDocumentElement().normalize();
            NodeList list = doc.getElementsByTagName("word");
            for (int temp = 0; temp < list.getLength(); temp++) {
                Node node = list.item(temp);
                if (node.getNodeType() == Node.ELEMENT_NODE) {
                    Element element = (Element) node;

                    NodeList originNode = element.getElementsByTagName(origin);
                    if(originNode != null){
                        Node item1 = originNode.item(0);
                        if(item1!= null){
                            String originWord = originNode.item(0).getTextContent();
                            if(originWord.equals(word)) {
                                NodeList destNode = element.getElementsByTagName(dest);
                                if (destNode != null) {
                                    Node item = destNode.item(0);
                                    if (item != null) {
                                        String destinationWord = destNode.item(0).getTextContent();

                                        text += destinationWord;
                                        exista = true;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        } catch (SAXException | IOException | ParserConfigurationException e) {
            e.printStackTrace();
        }
        if(!exista){
            text += "NU ESTE TRADUCERE";
        }

        return text;
    }
}
